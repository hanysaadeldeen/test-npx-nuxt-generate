import"./BMvg5McG.js";const t=""+new URL("Gallery.C0JhH8lw.svg",import.meta.url).href;export{t as _};
